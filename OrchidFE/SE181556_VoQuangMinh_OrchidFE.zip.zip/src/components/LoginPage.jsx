import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { users } from '../data/users';
import { useForm } from 'react-hook-form';
import toast, { Toaster } from 'react-hot-toast';

const LoginPage = () => {
  const { register, handleSubmit, formState: { errors } } = useForm();
  const [loginError, setLoginError] = useState('');
  const navigate = useNavigate();

  const onSubmit = (data) => {
    // so sánh từng user với thông tin đăng nhập
    const user = users.find(
      u => u.username === data.username && u.password === data.password
    );
      if (user) {
      // Store user info in localStorage
      localStorage.setItem('user', JSON.stringify({
        id: user.id,
        username: user.username,
        role: user.role
      }));
      
      // Kích hoạt sự kiện storage để thông báo cho NavBar biết người dùng đã đăng nhập
      window.dispatchEvent(new Event('storage'));
      
      toast.success('Login successful!');
      
      // Redirect based on role
      setTimeout(() => {
        if (user.role === 'admin') {
          navigate('/orchids'); // Admin goes to employee list
        } else {
          navigate('/view'); // Regular user goes to orchid list
        }
      }, 1500);
    } else {
      setLoginError('Invalid username or password');
      toast.error('Login failed. Please check your credentials.');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8 rounded-lg bg-white p-8 shadow-md">
        <div>
          <h2 className="mt-3 text-center text-3xl font-extrabold text-gray-900">
            Orchid Management System
          </h2>
          <p className="mt-2 text-center text-sm text-gray-600">
            Please sign in to your account
          </p>
        </div>
        
        <form className="mt-8 space-y-6" onSubmit={handleSubmit(onSubmit)}>
          <div className="rounded-md  -space-y-px">
            <div className=''>
              <label htmlFor="username" className="sr-only">Username</label>
              <input
                id="username"
                type="text"
                {...register("username", { required: "Username is required" })}
                className="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-t-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 sm:text-sm"
                placeholder="Username"
              />
              {errors.username && <p className="text-red-500 text-xs mt-1">{errors.username.message}</p>}
            </div>
            <div>
              <label htmlFor="password" className="sr-only">Password</label>
              <input
                id="password"
                type="password"
                {...register("password", { required: "Password is required" })}
                className="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 sm:text-sm"
                placeholder="Password"
              />
              {errors.password && <p className="text-red-500 text-xs mt-2 mb-2">{errors.password.message}</p>}
            </div>
          </div>

          {loginError && <p className="text-center text-red-500">{loginError}</p>}

          <div>
            <button
              type="submit"
              className="group relative w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
            >
              <span className="absolute left-0 inset-y-0 flex items-center pl-3">
                
              </span>
              Sign in
            </button>
          </div>
        </form>
        
        <div className="text-center mt-4">
          <p className="text-sm text-gray-600">
            Demo Accounts:
          </p>
          <p className="text-xs text-gray-500">
            Admin: admin / 123<br/>
            User: user / 123
          </p>
        </div>
      </div>
      <Toaster position="top-right" />
    </div>
  );
};

export default LoginPage;