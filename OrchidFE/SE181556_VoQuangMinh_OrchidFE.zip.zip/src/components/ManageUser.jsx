import { useState, useEffect } from 'react';
import { Container, Table, Button, Form, Modal as BootstrapModal, Alert } from 'react-bootstrap';
import { Modal, message } from 'antd';
import { users as initialUsers, isAdmin } from '../data/users';
import { useNavigate } from 'react-router';

const ManageUser = () => {
  const [users, setUsers] = useState([]);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [newUser, setNewUser] = useState({
    username: '',
    password: '',
    role: 'user',
    name: '',
    email: ''
  });
  const [errorMessage, setErrorMessage] = useState('');
  const navigate = useNavigate();

  // Load users from localStorage or use initial data
  useEffect(() => {
    setUsers(initialUsers);
    localStorage.setItem('usersData', JSON.stringify(initialUsers));
}, []); // Chạy 1 lần để load dữ liệu

useEffect(() => {
  const storedUser = JSON.parse(localStorage.getItem('user'));
  if (!storedUser || storedUser.role !== 'admin') {
    navigate('/home');
  }
}, [navigate]); // Chạy 1 lần sau khi component render

  // Save users to localStorage whenever they change
  useEffect(() => {
    if (users.length > 0) {
      localStorage.setItem('usersData', JSON.stringify(users));
    }
  }, [users]);

  const handleAddUser = () => {
    if (!newUser.username || !newUser.password || !newUser.name || !newUser.email) {
      setErrorMessage('Please fill in all required fields');
      return;
    }
    
    // Check if username already exists
    if (users.find(user => user.username === newUser.username)) {
      setErrorMessage('Username already exists');
      return;
    }

    const userToAdd = {
      ...newUser,
      id: users.length > 0 ? Math.max(...users.map(user => user.id)) + 1 : 1
    };

    setUsers([...users, userToAdd]);
    setShowAddModal(false);
    setErrorMessage('');
    setNewUser({
      username: '',
      password: '',
      role: 'user',
      name: '',
      email: ''
    });
  };

  const handleEditUser = () => {
    if (!currentUser.username || !currentUser.name || !currentUser.email) {
      setErrorMessage('Please fill in all required fields');
      return;
    }
    
    // Check if username already exists (excluding current user)
    if (users.some(user => user.username === currentUser.username && user.id !== currentUser.id)) {
      setErrorMessage('Username already exists');
      return;
    }

    const updatedUsers = users.map(user => 
      user.id === currentUser.id ? currentUser : user
    );

    setUsers(updatedUsers);
    setShowEditModal(false);
    setErrorMessage('');
    message.success('User updated successfully');
  };

  const handleDeleteUser = (id) => {
    // Prevent deleting the logged-in admin user
    const loggedInUser = JSON.parse(localStorage.getItem('user'));
    if (loggedInUser && loggedInUser.id === id) {
      setErrorMessage("You cannot delete your own account while logged in");
      return;
    }

    Modal.confirm({
      title: 'Confirm Deletion',
      content: 'Are you sure you want to delete this user?',
      okText: 'Yes',
      okType: 'danger',
      cancelText: 'No',
      onOk: () => {
        const updatedUsers = users.filter(user => user.id !== id);
        setUsers(updatedUsers);
        message.success('User deleted successfully');
      },
      onCancel: () => {
        message.info('User deletion canceled');
      }
    });
  };

  const openEditModal = (user) => {
    setCurrentUser({...user});
    setShowEditModal(true);
    // setErrorMessage('');
  };

  return (
    <Container className="py-4">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2>User Management</h2>
        <Button variant="primary" onClick={() => {
          setShowAddModal(true);
          setErrorMessage('');
        }}>
          Add New User
        </Button>
      </div>

      {errorMessage && (
        <Alert variant="danger" className="mb-4" dismissible onClose={() => setErrorMessage('')}>
          {errorMessage}
        </Alert>
      )}

      <Table striped bordered hover responsive>
        <thead className="bg-primary text-white">
          <tr>
            <th>ID</th>
            <th>Username</th>
            <th>Name</th>
            <th>Email</th>
            <th>Role</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {users.map(user => (
            <tr key={user.id}>
              <td>{user.id}</td>
              <td>{user.username}</td>
              <td>{user.name}</td>
              <td>{user.email}</td>
              <td>
                <span className={`badge ${user.role === 'admin' ? 'bg-danger' : 'bg-success'}`}>
                  {user.role}
                </span>
              </td>
              <td>
                <Button 
                  variant="outline-primary" 
                  size="sm" 
                  className="me-2"
                  onClick={() => openEditModal(user)}
                >
                  <i className="bi bi-pencil"></i> Edit
                </Button>
                <Button 
                  variant="outline-danger" 
                  size="sm"
                  onClick={() => handleDeleteUser(user.id)}
                >
                  <i className="bi bi-trash"></i> Delete
                </Button>
              </td>
            </tr>
          ))}
        </tbody>
      </Table>

      {/* Add User Modal */}
      <BootstrapModal show={showAddModal} onHide={() => setShowAddModal(false)}>
        <BootstrapModal.Header closeButton>
          <BootstrapModal.Title>Add New User</BootstrapModal.Title>
        </BootstrapModal.Header>
        <BootstrapModal.Body>
          {errorMessage && <Alert variant="danger">{errorMessage}</Alert>}
          <Form>
            <Form.Group className="mb-3">
              <Form.Label>Username*</Form.Label>              <Form.Control 
                type="text" 
                value={newUser.username}
                // onChange={(e) => setNewUser({...newUser, username: e.target.value})}
                required
              />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Password*</Form.Label>              <Form.Control 
                type="password" 
                value={newUser.password}
                // onChange={(e) => setNewUser({...newUser, password: e.target.value})}
                required
              />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Full Name*</Form.Label>              <Form.Control 
                type="text" 
                value={newUser.name}
                // onChange={(e) => setNewUser({...newUser, name: e.target.value})}
                required
              />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Email*</Form.Label>              <Form.Control 
                type="email" 
                value={newUser.email}
                // onChange={(e) => setNewUser({...newUser, email: e.target.value})}
                required
              />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Role</Form.Label>              <Form.Select
                value={newUser.role}
                onChange={(e) => setNewUser({...newUser, role: e.target.value})}
              >
                <option value="user">User</option>
                <option value="admin">Admin</option>
              </Form.Select>
            </Form.Group>
          </Form>
        </BootstrapModal.Body>
        <BootstrapModal.Footer>
          <Button variant="secondary" onClick={() => setShowAddModal(false)}>
            Cancel
          </Button>
          <Button variant="primary" onClick={handleAddUser}>
            Add User
          </Button>
        </BootstrapModal.Footer>
      </BootstrapModal>

      {/* Edit User Modal */}
      <BootstrapModal show={showEditModal} onHide={() => setShowEditModal(false)}>
        <BootstrapModal.Header closeButton>
          <BootstrapModal.Title>Edit User</BootstrapModal.Title>
        </BootstrapModal.Header>
        <BootstrapModal.Body>
          {errorMessage && <Alert variant="danger">{errorMessage}</Alert>}
          {currentUser && (
            <Form>
              <Form.Group className="mb-3">
                <Form.Label>Username*</Form.Label>                <Form.Control 
                  type="text" 
                  value={currentUser.username}
                //   onChange={(e) => setCurrentUser({...currentUser, username: e.target.value})}
                  required
                />
              </Form.Group>
              <Form.Group className="mb-3">
                <Form.Label>Password (leave blank to keep current)</Form.Label>                <Form.Control 
                  type="password" 
                  placeholder="New password" 
                //   onChange={(e) => setCurrentUser({...currentUser, password: e.target.value || currentUser.password})}
                />
              </Form.Group>
              <Form.Group className="mb-3">
                <Form.Label>Full Name*</Form.Label>                <Form.Control 
                  type="text" 
                  value={currentUser.name}
                //   onChange={(e) => setCurrentUser({...currentUser, name: e.target.value})}
                  required
                />
              </Form.Group>
              <Form.Group className="mb-3">
                <Form.Label>Email*</Form.Label>                <Form.Control 
                  type="email" 
                  value={currentUser.email}
                  onChange={(e) => setCurrentUser({...currentUser, email: e.target.value})}
                  required
                />
              </Form.Group>
              <Form.Group className="mb-3">
                <Form.Label>Role</Form.Label>                <Form.Select
                  value={currentUser.role}
                  onChange={(e) => setCurrentUser({...currentUser, role: e.target.value})}
                >
                  <option value="user">User</option>
                  <option value="admin">Admin</option>
                </Form.Select>
              </Form.Group>
            </Form>
          )}
        </BootstrapModal.Body>
        <BootstrapModal.Footer>
          <Button variant="secondary" onClick={() => setShowEditModal(false)}>
            Cancel
          </Button>          <Button variant="primary" onClick={handleEditUser}>
            Save Changes
          </Button>
        </BootstrapModal.Footer>
      </BootstrapModal>
    </Container>
  );
};

export default ManageUser;