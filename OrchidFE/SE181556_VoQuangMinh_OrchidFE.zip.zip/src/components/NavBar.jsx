import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { isAdmin, getCurrentUser, logout } from '../data/users';
import { useCart } from '../context/CartContext';

function NavBar() {
  const [user, setUser] = useState(null);
  const navigate = useNavigate();
  const { itemCount } = useCart();

  useEffect(() => {

    checkLoginStatus();

    // Thêm event listener để cập nhật trạng thái khi localStorage thay đổi
    window.addEventListener('storage', checkLoginStatus);
    
    return () => {
      window.removeEventListener('storage', checkLoginStatus);
    };
  }, []);

  const checkLoginStatus = () => {
    const currentUser = getCurrentUser();
    setUser(currentUser);
  };
  
  const handleLogout = () => {

    logout();
    setUser(null);

    navigate('/login');
  };
  
  return (
    <Navbar expand="lg" className="bg-body-tertiary">
      <Container>
        <Navbar.Brand as={Link} to="/view">Home</Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="me-auto">
            {isAdmin() && (
              <>
                <Nav.Link as={Link} to="/orchids">Employees</Nav.Link>
                <Nav.Link as={Link} to="/users">User Management</Nav.Link>
                <Nav.Link as={Link} to="/home">Orchids</Nav.Link>
              </>
            )}
          </Nav>          
          <Nav>
            {user && (
              <Nav.Link as={Link} to="/cart" className="d-flex align-items-center me-3">
                <div className="position-relative">
                  <i className="bi bi-cart3 fs-5"></i>
                  <span className="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                    {itemCount > 0 ? itemCount : 0}
                    <span className="visually-hidden">items in cart</span>
                  </span>
                </div>
              </Nav.Link>
            )}
            
            {user ? (

              
              <NavDropdown title={`Hello, ${user.username}`} id="basic-nav-dropdown" align="end">
                <NavDropdown.Item disabled>Role: {user.role}</NavDropdown.Item>
                <NavDropdown.Divider />
                <NavDropdown.Item onClick={handleLogout}>
                  <i className="bi bi-box-arrow-right me-2"></i>
                  Logout
                </NavDropdown.Item>
              </NavDropdown>
              
            ) : (              
              <>
                <Nav.Link as={Link} to="/login">Login</Nav.Link>
                <Nav.Link as={Link} to="/register">Register</Nav.Link>
              </>
            )}
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}

export default NavBar;