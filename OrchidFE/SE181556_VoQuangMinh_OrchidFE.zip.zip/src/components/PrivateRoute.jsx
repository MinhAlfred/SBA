import { Navigate, Outlet } from 'react-router-dom';
import { isAuthenticated, isAdmin } from '../data/users';

export const PrivateRoute = ({ children }) => {
  const auth = isAuthenticated();
  
  return auth ? children : <Navigate to="/login" />;
};

export const AdminRoute = ({ children }) => {
  const auth = isAuthenticated();
  const admin = isAdmin();
  
  if (!auth) {

    return <Navigate to="/login" />;
  }
  
  if (!admin) {

    return <Navigate to="/view" />;
  }
  
  return children;
};
