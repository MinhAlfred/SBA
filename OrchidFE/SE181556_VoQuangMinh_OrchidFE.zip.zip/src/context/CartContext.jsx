import { createContext, useContext, useState, useEffect } from 'react';


const CartContext = createContext();

export const useCart = () => {
  const context = useContext(CartContext);
  return context;
};

export const CartProvider = ({ children }) => {
  const [itemCount, setItemCount] = useState(0);
  const add = () => {
    setItemCount(prevCount => prevCount + 1);
  }

  return <CartContext.Provider value={{itemCount,add}}>{children}</CartContext.Provider>;
};