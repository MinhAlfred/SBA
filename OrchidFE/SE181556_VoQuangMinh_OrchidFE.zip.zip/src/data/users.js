// This file contains initialization data for user authentication
// Since we don't have an API yet, we'll use this data for login functionality

export const users = [
  {
    id: 1,
    username: "admin",
    password: "123",
    role: "admin",
    name: "Administrator",
    email: "admin@orchid.com"
  },
  {
    id: 2,
    username: "user",
    password: "123",
    role: "user",
    name: "Regular User",
    email: "user@orchid.com"
  }
];

// Helper function to check if a user is authenticated
export const isAuthenticated = () => {
  const user = localStorage.getItem('user');
  return user !== null;
};

// Helper function to get the current user
export const getCurrentUser = () => {
  const user = localStorage.getItem('user');
  return user ? JSON.parse(user) : null;
};

// Helper function to check if current user has admin role
export const isAdmin = () => {
  const user = getCurrentUser();
  return user && user.role === 'admin';
};

// Helper function to logout
export const logout = () => {
  localStorage.removeItem('user');
  // Kích hoạt sự kiện storage để NavBar có thể phản ứng với thay đổi
  window.dispatchEvent(new Event('storage'));
};
