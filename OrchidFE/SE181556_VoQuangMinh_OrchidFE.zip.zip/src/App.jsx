import 'bootstrap/dist/css/bootstrap.min.css';
import { Routes, Route, Navigate } from 'react-router-dom';
import ListOfOrchids from './components/ListOfOrchids';
import EditOrchid from './components/EditOrchid';
import HomeScreen from './components/HomeScreen';
import NavBar from './components/NavBar';
import ListOfEmployees from './components/ListOfEmployees';
import DetailOrchid from './components/DetailOrchid';
import LoginPage from './components/LoginPage';
import RegisterPage from './components/RegisterPage';
import ManageUser from './components/ManageUser';
import { PrivateRoute, AdminRoute } from './components/PrivateRoute';
import { isAuthenticated } from './data/users';
import { useEffect, useState } from 'react';
import { CartProvider } from './context/CartContext';

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(isAuthenticated());

  // Listen for changes in authentication status
  useEffect(() => {
    const checkAuthStatus = () => {
      setIsLoggedIn(isAuthenticated());
    };

    window.addEventListener('storage', checkAuthStatus);
    return () => {
      window.removeEventListener('storage', checkAuthStatus);
    };
  }, []);
 
  return (
    <CartProvider>
      { <NavBar />}
      <Routes>
        {/* Public routes */}
        <Route path="/login" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />
        
        {/* Protected routes for all authenticated users */}
        <Route path="/home" element={
          <PrivateRoute>
            <ListOfOrchids />
          </PrivateRoute>
        } />
        <Route path="/view" element={
            <HomeScreen />
        } />
        <Route path="/detail/:id" element={
          <PrivateRoute>
            <DetailOrchid />
          </PrivateRoute>
        } />
        
        {/* Protected routes for admin only */}
        <Route path="/orchids" element={
          <AdminRoute>
            <ListOfEmployees />
          </AdminRoute>
        } />
        <Route path="/edit/:id" element={
          <AdminRoute>
            <EditOrchid />
          </AdminRoute>
        } />
        <Route path="/users" element={
          <AdminRoute>
            <ManageUser />
          </AdminRoute>
        } />
        
        {/* Default route */}
        <Route path="/" element={<Navigate to="/login" />} />
        <Route path="*" element={<Navigate to="/login" />} />
      </Routes>
    </CartProvider>
  );
}

export default App;